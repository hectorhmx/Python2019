if False:
	print('Este código no hace nada porque la condición es falsa')