condicion=''
while (condicion!='si'):
	condicion = input('¿Quieres salir del ciclo?\n')