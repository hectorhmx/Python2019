a = input("¿Tu crush te hace caso?\nPosibles respuestas:\n\t*Sí\n\t*No\n\t*A veces sí y a veces no\n")
if a == 'Sí':
	print('Que weno OwO')
else:
	if a == 'No':
		print('Que malo UwU')
	if a == 'A veces sí y a veces no':
		print("Respétate príncipe/princesa, vales mil <3")
	else:
		print('No insertaste una opción válida')