a = int(input('Inserta un número: '))
if a%2 == 0:
	print('El '+str(a)+' es par.')
else:
	print('El '+str(a)+' es impar.')