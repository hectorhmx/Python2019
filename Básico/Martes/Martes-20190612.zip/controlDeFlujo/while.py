while(True):
	print('Este ciclo es infinito porque la condición siempre es verdadera')