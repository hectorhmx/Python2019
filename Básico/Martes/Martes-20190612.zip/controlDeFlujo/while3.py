materias = 10
servicioSocial=''
while (materias!=0 and servicioSocial != 'si'):
	materias = input('Cuántas materias te faltan para terminar tus créditos?:\t')
	servicioSocial = input('Ya hiciste tu servicio social?:\t')
print('\nFelicidades, estás cerca de titularte!\n')