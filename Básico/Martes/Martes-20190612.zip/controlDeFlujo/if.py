if True:
	print('Este código hace algo porque la condición es verdadera')